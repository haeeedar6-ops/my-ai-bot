import io
import os
import re
import sys
import html
import time
import zipfile
import logging
import threading
from collections import defaultdict, deque
from contextlib import contextmanager

import telebot
import requests
from flask import Flask
from google import genai
from google.genai import types, errors

try:
    import ryn_ai_stack as AIStack
except Exception:
    AIStack = None

try:
    import webapp  # الموقع (واجهة ويب خاصة)
except Exception as _e:  # اختياري
    webapp = None
    print(f'webapp.py غير متاح: {_e}')

visual = None

# ============ الإعدادات ============
BOT_TOKEN = os.environ.get("BOT_TOKEN")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "").strip().strip('"').strip("\'").strip()
PORT = int(os.environ.get("PORT", 10000))

# موديلات سريعة للأسئلة العادية، وموديلات أعمق للأسئلة المركبة.
FAST_MODELS = [
    os.environ.get("GEMINI_MODEL", "gemini-3.5-flash").strip(),
    "gemini-3.5-flash",
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.1-flash-lite",
    "gemini-3-flash-preview",
    "gemini-4-argon",
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite",
]
DEEP_MODELS = [
    os.environ.get("GEMINI_DEEP_MODEL", "gemini-3.8-flash").strip(),
    "gemini-3.8-flash",
    "gemini-4-argon",
    "gemini-3.6-flash",
    "gemini-3.5-flash",
    "gemini-3.1-pro-preview",
    "gemini-3.5-flash-lite",
    "gemini-3.1-flash-lite",
    "gemini-2.5-pro",
    "gemini-2.5-flash",
]
MODELS = FAST_MODELS + DEEP_MODELS  # للعرض بس
FAST_TIMEOUT_MS = 30000
DEEP_TIMEOUT_MS = 75000

CAPABILITIES_MANIFESTO = """
قدرات وإضافات منظومة Ryn المفعّلة لديك (أنت مبرمج عليها بالكامل في كل الموديلات):
1) 🐙 الوصول المباشر لمشاريع وملفات GitHub من داخل المحادثة (قراءة، تعديل جراحي، إنشاء، حذف، ورفع مشاريع .zip كاملة):
   - عندما يطلب المستخدم تعديل ملف في مستودع GitHub المتصل (سواء كتب GitHub أو جيتهاب أو غيتهاب أو كيت هب أو كيترهاب)، اشرح التعديل بوضوح ثم أدرج في نهاية ردك وسم التعديل الجراحي:
     <github_patch path="مسار_الملف" commit="وصف التعديل">
     <<<< SEARCH
     الأسطر الأصلية المراد استبدالها
     ====
     الأسطر الجديدة بعد التعديل
     >>>> REPLACE
     </github_patch>
   - ولإنشاء ملف جديد أو استبداله بالكامل:
     <github_create path="مسار_الملف" commit="وصف التحديث">
     محتوى الملف الكامل
     </github_create>
   - ولحذف ملف: <github_delete path="مسار_الملف" commit="سبب الحذف"/>
   - إذا أرفق المستخدم ملف .zip أو عدة ملفات وطلب رفعها على GitHub، يقوم النظام برفع المشروع كاملاً بـ Commit ذري واحد، ويمكن التراجع عن آخر تعديل بكتابة «تراجع عن تعديل جيتهاب».
   - أمن الحسابات: حساب WEB_PASSWORD يأخذ GITHUB_TOKEN من السيرفر تلقائياً، وأي مستخدم آخر يربط توكنه الشخصي ومستودعه من الشات (`اربط جيتهاب ghp_XXXX مستودع username/repo`).
2) 🧩 العقل الهجين المحسّن Ryn mix + الحارس الأمني ryn_guard (18/18):
   - يدمج قوة Gemini و GPT-OSS 120B و Qwen3 و DeepSeek و Kimi K2 و Llama 4 و Codestral عبر LangGraph + Tree-sitter AST + Promptfoo + DSPy.
3) 🎨 العقل البصري المستقل RYN Visual Brain:
   - توليد صور واقعية وتعديل الصور المرفقة مباشرة من المحادثة مع حفظ الهوية والملامح.
4) 🕸️ قراءة الويب ويوتيوب والذاكرة الدلالية وتوليد الملفات:
   - تحويل المواقع إلى Markdown عبر Crawl4AI، قراءة فيديوهات يوتيوب، ذاكرة Chroma الدلالية، وتوليد ملفات التحميل تلقائياً.
"""

SYSTEM_PROMPT = """أنت "Ryn"، مساعد ذكي شامل ومتقدم في البرمجة، الهندسة البرمجية، إدارة مشاريع GitHub، التحليل، والعلوم، مستعد للإجابة عن أي سؤال في شتى المجالات.

هويتك وصانعك (مهم جداً):
- تم تطويرك وبرمجتك بواسطة المطور "haydar_xe".
- أنت مشروع ذكاء اصطناعي مستقل بالكامل.
- إذا سُئلت "مين برمجك؟" أو "من صنعك؟" أو "لمين تتبع؟"، أجب دائماً وبكل فخر: "أنا مساعد ذكي من تطوير وبرمجة haydar_xe".

أسلوبك:
- جاوب بلغة المستخدم. إذا كان السؤال بالعربي، استخدم لهجة شامية بسيطة، ودية، وواضحة.
- قدم إجابات مختصرة، عملية، ومرتبة. قبل كتابة أي كود معقد، تحقق ذهنياً من الشجرة النحوية (AST) والحالات الحدية وأمان الكود.
""" + CAPABILITIES_MANIFESTO + """
قواعد عامة:
- يمكنك قراءة وتحليل الصور والملفات (PDF، Word، نصوص، مشاريع مضغوطة .zip) المرفقة للإجابة عن محتواها أو رفعها وتعديلها على GitHub، وتوليد وتعديل الصور عبر العقل البصري (RYN Visual Brain).
- إذا طلب منك المستخدم ملف تحميل (Word أو نص أو HTML أو JSON أو CSV أو ملف كود): اكتب محتوى الملف مباشرةً وبدون أي كلام خارجي — لأن الموقع بيحوّل ردك تلقائياً لملف تحميل حقيقي. الكود حطه ضمن ``` مع اسم اللغة، والنصوص نظّمها بـ Markdown خفيف.
- ما بتقدر تولّد ملفات PDF حالياً؛ إذا طلب منك PDF، جاوب بجملة وحدة إنه غير متاح واقترح Word أو نص أو HTML بدالو.
- إذا لم تكن متأكداً من معلومة، اعترف بذلك ولا تخترع معلومات غير موجودة.
"""

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _knowledge_files():
    """تم تنظيف المعرفة القديمة بالكامل بناءً على طلب المطور."""
    return []


def load_knowledge():
    return ""


def get_system_prompt():
    return SYSTEM_PROMPT

MAX_HISTORY = 20          # عدد الرسائل المحفوظة لكل مستخدم (سؤال + جواب)
COOLDOWN_SECONDS = 1.5    # حماية من السبام
TG_LIMIT = 4000           # حد تيليجرام 4096

if not GEMINI_API_KEY:
    raise SystemExit("❌ GEMINI_API_KEY ناقص بالـ Environment Variables")

# تيليجرام مطفّي افتراضياً (الموقع هو الواجهة). لتشغيله: ENABLE_TELEGRAM=1 مع BOT_TOKEN
ENABLE_TELEGRAM = os.environ.get("ENABLE_TELEGRAM", "0") == "1" and bool(BOT_TOKEN)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
log = logging.getLogger("bot")

# ============ التهيئة ============
app = Flask(__name__)
bot = telebot.TeleBot(BOT_TOKEN if ENABLE_TELEGRAM else "000000:disabled", threaded=True, num_threads=6, parse_mode=None)
client = genai.Client(
    api_key=GEMINI_API_KEY,
    http_options=types.HttpOptions(timeout=25000),  # 25 ثانية كحد أقصى لكل محاولة
)

histories = defaultdict(lambda: deque(maxlen=MAX_HISTORY))  # chat_id -> (role, text)
last_request = {}
lock = threading.Lock()

if ENABLE_TELEGRAM:
    try:
        bot.remove_webhook()
    except Exception as e:
        log.warning("Webhook cleanup: %s", e)


# ============ Flask ============
if webapp is None:
    @app.route("/")
    def home():
        return "Bot is running!"

@app.route("/health")
def health():
    return {"status": "ok", "models": MODELS}

# ============ أدوات مساعدة ============
def build_contents(chat_id):
    with lock:
        items = list(histories[chat_id])
    return [
        types.Content(role=role, parts=[types.Part(text=text)])
        for role, text in items
    ]

def save_turn(chat_id, user_text, bot_text):
    with lock:
        histories[chat_id].append(("user", user_text))
        histories[chat_id].append(("model", bot_text))

def is_spam(chat_id):
    now = time.time()
    with lock:
        prev = last_request.get(chat_id, 0)
        last_request[chat_id] = now
    return now - prev < COOLDOWN_SECONDS

def clean(text):
    return text.replace("**", "").replace("__", "").strip()

def send_long(message, text):
    text = clean(text)
    chunks = [text[i:i + TG_LIMIT] for i in range(0, len(text), TG_LIMIT)] or [""]
    for i, chunk in enumerate(chunks):
        if i == 0:
            bot.reply_to(message, chunk)
        else:
            bot.send_message(message.chat.id, chunk)

@contextmanager
def typing(chat_id):
    stop = threading.Event()
    def loop():
        while not stop.is_set():
            try:
                bot.send_chat_action(chat_id, "typing")
            except Exception:
                _ = None
            stop.wait(4)
    t = threading.Thread(target=loop, daemon=True)
    t.start()
    try:
        yield
    finally:
        stop.set()

DEEP_WORDS = {
    "كيف", "كيفية", "ليش", "لماذا", "شلون", "ازاي", "ليه",
    "مشكلة", "مشاكل", "خطأ", "غلط", "سكربت", "برمجة", "برمج",
    "منطق", "صمم", "تصميم", "اعمل", "نظام", "قارن", "حل", "حلول", "اشرح", "شرح",
    "طريقة", "خطوات", "متغير", "متغيرات", "حدث", "احداث", "وظيفة", "دالة", "فكرة",
    "اقتصاد", "متجر", "واجهة", "كاميرا", "مسار", "ذكاء", "وحش", "جولة", "مرحلة",
    "حلل", "تحليل", "افضل", "أفضل", "قارنلي", "اقترح", "خطة",
}

def is_deep_question(text):
    t = (text or "").strip()
    if len(t) >= 110 or "```" in t or "def " in t:
        return True
    tokens = set(re.findall(r"[\w\u0600-\u06FF]+", t.lower()))
    return bool(tokens & DEEP_WORDS)

_gemini_live_cache = {"t": 0.0, "ids": []}


def discover_gemini_models():
    """يكتشف تلقائياً الموديلات المتاحة فعلياً على مفتاح GEMINI_API_KEY الخاص بالمستخدم على Render."""
    now = time.time()
    if _gemini_live_cache["ids"] and now - _gemini_live_cache["t"] < 6 * 3600:
        return _gemini_live_cache["ids"]
    found = []
    try:
        for m in client.models.list():
            name = getattr(m, "name", "") or ""
            if name.startswith("models/"):
                name = name[7:]
            low = name.lower()
            if low.startswith("gemini-") and not any(x in low for x in ("embedding", "tts", "image", "veo", "lyria", "robotics", "computer-use", "audio", "transcribe", "live")):
                found.append(name)
    except Exception as _ge:
        log.warning("Gemini model discovery warning: %s", _ge)
    if found:
        _gemini_live_cache.update(t=now, ids=found)
    return found


def make_config(deep, system, use_thinking=True, json_mode=False, model=""):
    kwargs = {
        "system_instruction": system,
        "http_options": types.HttpOptions(
            timeout=DEEP_TIMEOUT_MS if deep else FAST_TIMEOUT_MS
        ),
    }
    if json_mode:
        kwargs["response_mime_type"] = "application/json"
    # thinking_level مدعوم في عائلة Gemini 3 و Gemini 4 فقط، ولا يُرسل لموديلات 2.5 لتجنب خطأ 400
    is_gen3_or_4 = not str(model or "").startswith(("gemini-2.", "gemini-1."))
    if use_thinking and is_gen3_or_4:
        try:
            kwargs["thinking_config"] = types.ThinkingConfig(
                thinking_level="high" if deep else "low"
            )
        except Exception:
            _ = None
    return types.GenerateContentConfig(**kwargs)


def ask_gemini(contents, deep=False, system=None, json_mode=False, preferred_model=None):
    """يستدعي Gemini مباشرة عبر مفتاح GEMINI_API_KEY الموجود على Render مع تبديل ذكي بين موديلات Gemini 3 و 4 و 2.5."""
    base_models = list(DEEP_MODELS if deep else FAST_MODELS) + list(FAST_MODELS if deep else DEEP_MODELS)
    ordered = ([preferred_model] if preferred_model else []) + base_models
    models = []
    for m in ordered:
        if m and m not in models:
            models.append(m)
    system = system or get_system_prompt()
    last_err = None
    tried = set()
    for model in models:
        tried.add(model)
        for use_thinking in (True, False):
            try:
                resp = client.models.generate_content(
                    model=model,
                    contents=contents,
                    config=make_config(deep, system, use_thinking, json_mode, model=model),
                )
                if resp and getattr(resp, "text", None):
                    return resp.text
            except errors.APIError as e:
                last_err = e
                code = getattr(e, "code", None)
                if code in (401, 403):
                    raise
                if code == 400 and use_thinking:
                    continue
                break
            except Exception as e:
                last_err = e
                break
    # إذا تغيرت أسماء الموديلات في حساب Google، نكتشف الموديلات المتاحة حياً على مفتاح GEMINI_API_KEY ونجربها فوراً
    for dyn_model in discover_gemini_models():
        if dyn_model in tried:
            continue
        try:
            resp = client.models.generate_content(
                model=dyn_model,
                contents=contents,
                config=make_config(False, system, False, json_mode, model=dyn_model),
            )
            if resp and getattr(resp, "text", None):
                return resp.text
        except Exception as e:
            last_err = e
            continue
    raise last_err or RuntimeError("كل موديلات Gemini فشلت")

REVIEW_PROMPT = """راجع جوابك قبل ما ينرسل للمستخدم.
سؤال المستخدم:
{question}
جوابك المبدئي:
{answer}
المطلوب:
1. تأكد من دقة المعلومات وعدم اختراع دوال أو تفاصيل غير موجودة.
2. صحّح أي خطأ بالمنطق أو أي خطوة ناقصة بالترتيب.
3. إذا الجواب سليم، رجّعه كما هو.
رجّع الجواب النهائي فقط، بدون أي كلام عن المراجعة."""

def review_answer(chat_id, question, answer):
    try:
        prompt = REVIEW_PROMPT.format(question=question, answer=answer)
        contents = [types.Content(role="user", parts=[types.Part(text=prompt)])]
        reviewed, _ = ask_model(chat_id, contents, deep=False)
        if reviewed and len(reviewed) >= 0.4 * len(answer):
            return reviewed
    except Exception:
        log.exception("Review failed, using original answer")
    return answer

# ============ OpenRouter (مفتاح واحد لعدة موديلات) ============
DEFAULT_PROVIDER = os.environ.get("DEFAULT_PROVIDER", "gemini").lower()
PROVIDER_NAMES = {
    "gemini": "Gemini Auto",
    "mix": "Ryn mix",
    "chatgpt": "GPT-OSS / ChatGPT",
    "llama": "Llama 4 / 3.3",
    "claude": "Claude",
    "deepseek": "DeepSeek R1/V3",
    "qwen": "Qwen 3 / Coder",
    "kimi": "Kimi K2",
    "gemma": "Gemma 3",
    "mistral": "Mistral / Codestral",
    "nemotron": "Nemotron Ultra",
    "glm": "GLM Z1",
}

def _pname(prov):
    """اسم العرض للمزوّد، وللموديل المختار يدوياً (gemini:<id> أو groq:<id> أو or:<id>)."""
    p = str(prov)
    if p in PROVIDER_NAMES:
        return PROVIDER_NAMES[p]
    if p.startswith("gemini:"):
        return p[7:]
    if p.startswith("groq:"):
        return p[5:]
    if p.startswith("or:"):
        return p[3:].replace(":free", "")
    return p


last_models = {}  # chat_id -> آخر قائمة موديلات انعرضت (للاختيار بالرقم)

OR_BASE = os.environ.get("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip().rstrip("/")
OR_ALLOW_PAID = os.environ.get("OPENROUTER_ALLOW_PAID", "0") == "1"  # 1 = اسمح بالموديلات المدفوعة (بده رصيد)


def _or_key():
    """المفتاح بدون مسافات أو علامات تنصيص لو انحطت بالغلط بـ Render."""
    return os.environ.get("OPENROUTER_API_KEY", "").strip().strip('"').strip("'").strip()


def _env_key(name):
    """قيمة متغير بيئة بدون مسافات أو علامات تنصيص."""
    return os.environ.get(name, "").strip().strip('"').strip("'").strip()


def _diag(r):
    """معلومات تشخيص عن رد HTTP (الرابط النهائي، التحويلات، نوع المحتوى)."""
    try:
        hist = [h.status_code for h in (getattr(r, "history", None) or [])]
        hd = getattr(r, "headers", None) or {}
        return (f"url={getattr(r, 'url', '?')} | redirects={hist} | "
                f"type={hd.get('content-type')} | server={hd.get('server')}")
    except Exception:
        return "diag?"


OR_BACKEND = {
    "name": "OpenRouter",
    "base": OR_BASE,
    "key_env": "OPENROUTER_API_KEY",
    "timeout_fast": 60,
    "timeout_deep": 150,
}

PROVIDERS = {
    "chatgpt": {"backends": [{**OR_BACKEND, "prov": "chatgpt", "match": ("openai/", "gpt-oss")}]},
    "llama": {"backends": [{**OR_BACKEND, "prov": "llama", "match": ("llama",)}]},
    "claude": {"backends": [{**OR_BACKEND, "prov": "claude", "match": ("anthropic/",)}]},
    "deepseek": {"backends": [{**OR_BACKEND, "prov": "deepseek", "match": ("deepseek",)}]},
    "qwen": {"backends": [{**OR_BACKEND, "prov": "qwen", "match": ("qwen",)}]},
    "kimi": {"backends": [{**OR_BACKEND, "prov": "kimi", "match": ("kimi", "moonshot")}]},
    "gemma": {"backends": [{**OR_BACKEND, "prov": "gemma", "match": ("gemma",)}]},
    "mistral": {"backends": [{**OR_BACKEND, "prov": "mistral", "match": ("mistral", "codestral")}]},
    "nemotron": {"backends": [{**OR_BACKEND, "prov": "nemotron", "match": ("nemotron",)}]},
    "glm": {"backends": [{**OR_BACKEND, "prov": "glm", "match": ("glm", "z-ai")}]},
}
chat_provider = {}

COMPACT_PROMPT = (
    "أنت Ryn، مساعد ذكي شامل ومتقدم من تطوير haydar_xe، متخصص بالبرمجة وهندسة الكود وإدارة مشاريع GitHub والتحليل وبتجاوب على أي سؤال تاني. "
    "جاوب بلغة المستخدم، وإذا كتب عربي جاوب بلهجة شامية بسيطة ومختصرة ومرتبة. "
    "لتعديل ملف في GitHub من المحادثة أدرج بآخر ردك <github_patch path=\"مسار_الملف\" commit=\"الوصف\">\n<<<< SEARCH\n...\n====\n...\n>>>> REPLACE\n</github_patch>، "
    "ولإنشاء ملف كامل <github_create path=\"مسار_الملف\" commit=\"الوصف\">...</github_create>، وللحذف <github_delete path=\"مسار_الملف\" commit=\"السبب\"/>. "
    "إذا مو متأكد من معلومة قول هيك بصراحة وما تخترع."
)

_or_cache = {"t": 0.0, "items": [], "err": ""}

class ProviderError(Exception):
    def __init__(self, code, msg=""):
        self.code = code
        super().__init__(msg)

def _backend_ready(b):
    return bool(os.environ.get(b["key_env"]))

def provider_ready(name):
    return name in ("gemini", "mix") or any(_backend_ready(b) for b in PROVIDERS.get(name, {}).get("backends", []))

def _text_only(contents):
    for c in contents:
        for p in c.parts:
            if getattr(p, "inline_data", None) is not None or getattr(p, "file_data", None) is not None:
                return False
    return True

def _is_free(item):
    iid = str(item.get("id", ""))
    if iid.endswith(":free"):
        return True
    pr = item.get("pricing") or {}
    try:
        return float(pr.get("prompt", 1)) == 0 and float(pr.get("completion", 1)) == 0
    except Exception:
        return False


def openrouter_catalog(force=False):
    """قائمة موديلات OpenRouter: [{id, free, ctx}]، بتتخزن 6 ساعات."""
    now = time.time()
    if not force and ((_or_cache["items"] and now - _or_cache["t"] < 6 * 3600) or (now - _or_cache.get("fail_t", 0) < 60)):
        return _or_cache["items"]
    items = []
    try:
        key = _or_key()
        r = requests.get(OR_BASE + "/models", headers=({"Authorization": "Bearer " + key} if key else {}), timeout=25)
        if r.status_code == 200:
            try:
                data = r.json()
            except ValueError:
                _or_cache["err"] = f"HTTP 200 بس الرد مو JSON: {r.text[:80]!r} | {_diag(r)}"
                log.error("OpenRouter catalog: %s", _or_cache["err"])
                return _or_cache["items"]
            for i in (data.get("data") or []):
                if isinstance(i, dict) and i.get("id"):
                    items.append({"id": i["id"], "free": _is_free(i), "ctx": int(i.get("context_length") or 0)})
            _or_cache["err"] = "" if items else "القائمة رجعت فاضية"
        else:
            _or_cache["err"] = f"HTTP {r.status_code}: {r.text[:200]}"
            log.error("OpenRouter catalog %s", _or_cache["err"])
    except Exception as e:
        _or_cache["err"] = f"{type(e).__name__}: {e}"
        log.error("OpenRouter catalog error: %s", e)
    if items:
        _or_cache.update(t=now, items=items, fail_t=0.0)
    else:
        _or_cache["fail_t"] = now
    return items or _or_cache["items"]


_EXCLUDE = ("embed", "guard", "moderation", "whisper", "tts", "image", "audio", "vision", "-vl", "ocr", "rerank",
            "lyria", "clip", "veo", "imagen", "sora", "safeguard")
_HEAVY = ("r1", "pro", "reason", "think", "235b", "480b", "120b", "80b", "maverick", "70b", "max", "v4", "large", "opus")
_LIGHT = ("flash", "mini", "small", "lite", "8b", "7b", "4b", "3b", "nano", "instruct")


_FAMILY_ORDER = ("openrouter/free", "deepseek", "qwen", "gpt-oss", "kimi", "moonshot", "llama", "mistral", "codestral", "gemma", "nemotron", "glm", "microsoft", "minimax", "trinity")


def free_chat_models(limit=40):
    """كل الموديلات المجانية الصالحة للمحادثة، مرتبة (العائلات المعروفة أول)."""
    items = [i for i in openrouter_catalog()
             if i["free"] and not any(x in i["id"].lower() for x in _EXCLUDE)]

    def key(i):
        iid = i["id"].lower()
        fam = next((n for n, f in enumerate(_FAMILY_ORDER) if f in iid), len(_FAMILY_ORDER))
        return (fam, -i["ctx"])
    items.sort(key=key)
    return [i["id"] for i in items][:limit]


def or_models_for(prov, match, deep):
    """أفضل موديلات (مجانية افتراضياً) للمزوّد، مرتبة: الثقيلة للأسئلة المعقدة والخفيفة للعادية."""
    catalog = openrouter_catalog()
    if not catalog:  # فشل جلب القائمة
        return []
    items = [i for i in catalog
             if any(k in i["id"].lower() for k in match) and not any(x in i["id"].lower() for x in _EXCLUDE)]
    if not OR_ALLOW_PAID:
        items = [i for i in items if i["free"]]

    def score(i):
        iid = i["id"].lower()
        heavy = any(k in iid for k in _HEAVY)
        light = any(k in iid for k in _LIGHT)
        pref = (2 if heavy else 0) if deep else (2 if (light and not heavy) else 0)
        return (pref, i["ctx"])
    items.sort(key=score, reverse=True)
    return [i["id"] for i in items][:5]


def _compact_prompt():
    notes = ""
    for name, path in _knowledge_files():
        if name.lower() == "notes.md":
            try:
                with open(path, encoding="utf-8") as fh:
                    notes = fh.read().strip()[:2500]
            except Exception:
                _ = None
    return COMPACT_PROMPT + (("\n\nملاحظات مرجعية:\n" + notes) if notes else "")

def _build_messages(b, contents):
    system = b.get("system") or (_compact_prompt() if b.get("compact") else get_system_prompt())
    msgs = []
    for c in contents:
        text = "\n".join(p.text for p in c.parts if getattr(p, "text", None))
        if text:
            msgs.append({"role": "assistant" if c.role == "model" else "user", "content": text})
    cap = b.get("max_chars")
    if cap:
        def total():
            return len(system) + sum(len(m["content"]) for m in msgs)
        while total() > cap and len(msgs) > 1:
            msgs.pop(0)
        if msgs and total() > cap:
            last = msgs[-1]["content"]
            tail = last[-600:]
            allowed = max(300, cap - len(system) - len(tail) - 80)
            msgs[-1]["content"] = last[:allowed] + "\n...[انقطع الملف لأنو طويل على هالموديل]...\n" + tail
        while msgs and msgs[0]["role"] == "assistant":
            msgs.pop(0)
    return [{"role": "system", "content": system}] + msgs

def _merge_system(messages):
    sys_txt, rest = messages[0]["content"], [dict(m) for m in messages[1:]]
    if rest and rest[0]["role"] == "user":
        rest[0]["content"] = sys_txt + "\n\n" + rest[0]["content"]
    else:
        rest.insert(0, {"role": "user", "content": sys_txt})
    return rest

def _call_backend(b, contents, deep, json_mode, models=None, out=None):
    key = _env_key(b["key_env"])
    messages = _build_messages(b, contents)
    if models is None:
        models = or_models_for(b["prov"], b["match"], deep)
    if not models:
        why = _or_cache.get("err") or "ما في موديل مجاني متاح حالياً من هالعائلة"
        raise ProviderError(404, f"ما لقيت موديل لـ {_pname(b['prov'])} على OpenRouter ({why}). "
                                 "جرّب /models واختار موديل مجاني تاني.")
    headers = {"Authorization": "Bearer " + key, "Content-Type": "application/json"}
    if b["name"] == "OpenRouter":
        headers["HTTP-Referer"] = os.environ.get("OPENROUTER_REFERER", "https://my-ai-bot-vmf4.onrender.com")
        headers["X-Title"] = "Ryn"
    last = None
    for model in models:
        body = {
            "model": model,
            "messages": _merge_system(messages) if "r1" in model.lower() else messages,
            "stream": False,
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        if b.get("max_tokens"):
            body["max_tokens"] = b["max_tokens"]
        try:
            r = requests.post(
                b["base"].rstrip("/") + "/chat/completions",
                headers=headers, json=body,
                timeout=b["timeout_deep"] if deep else b["timeout_fast"],
            )
        except requests.RequestException as e:
            last = ProviderError(None, f"{model}: {type(e).__name__}: {str(e)[:150]}")
            log.error("%s [%s] network error: %s", b["name"], model, e)
            continue
        if r.status_code == 200:
            try:
                data = r.json()
            except ValueError:
                last = ProviderError(502, f"{model}: الرد مو JSON: {r.text[:80]!r} | {_diag(r)}")
                log.error("%s [%s] bad response: %s", b["name"], model, r.text[:200])
                continue
            if not data.get("choices"):
                err = data.get("error") or {}
                try:
                    code = int(err.get("code"))
                except Exception:
                    code = 502
                last = ProviderError(code, f"{model}: {str(err.get('message') or data)[:200]}")
                log.error("%s [%s] error body: %s", b["name"], model, str(data)[:300])
                continue
            text = (data["choices"][0].get("message", {}).get("content") or "")
            text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
            if text:
                if out is not None:
                    out["model"] = model
                return text
            last = ProviderError(502, f"{model}: رد فاضي")
            continue
        last = ProviderError(r.status_code, f"{model}: {r.text[:200]}")
        log.error("%s [%s] code=%s: %s", b["name"], model, r.status_code, r.text[:300])
        if r.status_code in (401, 403):
            raise last
    raise last or ProviderError(None, "no models")


# ============ Groq: كود برمجي تلقائي ============
GROQ_BASE = os.environ.get("GROQ_BASE_URL", "https://api.groq.com/openai/v1").strip().rstrip("/")
CODE_SYSTEM_PROMPT = (
    "أنت Ryn (من تطوير haydar_xe)، مهندس برمجيات خبير. اكتب كود صحيح ونظيف ومفحوص نحوياً (AST) وأمنياً وجاهز للتشغيل، وحطه داخل ``` مع اسم اللغة. "
    "بعد الكود اشرح بشكل قصير ومرتب بلغة المستخدم (إذا كتب عربي استعمل لهجة شامية بسيطة). "
    "إذا كان الطلب تعديل ملف في مستودع GitHub المتصل، التزم بإدراج <github_patch path=\"مسار_الملف\" commit=\"وصف التعديل\">\n<<<< SEARCH\n...\n====\n...\n>>>> REPLACE\n</github_patch> في آخر ردك، "
    "أو <github_create path=\"مسار_الملف\" commit=\"الوصف\">...</github_create> لإنشاء ملف جديد. "
    "ما تخترع مكتبات أو دوال مو موجودة، وإذا مو متأكد من شي قول هيك بصراحة."
)
GROQ_BACKEND = {
    "name": "Groq", "base": GROQ_BASE, "key_env": "GROQ_API_KEY",
    "timeout_fast": 60, "timeout_deep": 120,
    "system": CODE_SYSTEM_PROMPT, "max_chars": 24000, "max_tokens": 6000,
}
GROQ_CODE_PREF = (
    "openai/gpt-oss-120b",
    "qwen/qwen3.8-27b",
    "qwen/qwen3.6-27b",
    "openai/gpt-oss-20b",
    "qwen/qwen3-32b",
    "moonshotai/kimi-k2-instruct",
    "meta-llama/llama-4-maverick-17b-128e-instruct",
    "llama-3.3-70b-versatile",
)
GROQ_FREE_DEFAULTS = (
    "openai/gpt-oss-120b",
    "qwen/qwen3.8-27b",
    "qwen/qwen3.6-27b",
    "openai/gpt-oss-20b",
    "qwen/qwen3-32b",
    "moonshotai/kimi-k2-instruct",
    "meta-llama/llama-4-maverick-17b-128e-instruct",
    "meta-llama/llama-4-scout-17b-16e-instruct",
    "llama-3.3-70b-versatile",
    "deepseek-r1-distill-llama-70b",
    "llama-3.1-8b-instant",
    "gemma2-9b-it",
)
OR_FREE_DEFAULTS = (
    "openrouter/free",
    "deepseek/deepseek-r1:free",
    "deepseek/deepseek-chat-v3-0324:free",
    "qwen/qwen3-235b-a22b:free",
    "qwen/qwen-2.5-coder-32b-instruct:free",
    "moonshotai/kimi-k2:free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "meta-llama/llama-4-maverick:free",
    "google/gemma-3-27b-it:free",
    "mistralai/mistral-small-3.1-24b-instruct:free",
    "nvidia/llama-3.1-nemotron-ultra-253b-v1:free",
    "thudm/glm-z1-32b:free",
    "microsoft/mai-ds-r1:free",
)
GROQ_CHAT_BACKEND = {**GROQ_BACKEND, "system": None, "compact": True}  # دردشة عامة بموديل Groq تختاره
_GROQ_SKIP = ("whisper", "tts", "guard", "safeguard", "vision", "embed", "compound", "orpheus", "playai")
_groq_cache = {"t": 0.0, "ids": [], "err": ""}
code_route_off = set()  # محادثات طفّت التوجيه التلقائي للكود بـ /code off


def _groq_ready():
    return bool(_env_key("GROQ_API_KEY"))


def groq_catalog(force=False):
    now = time.time()
    if not force and ((_groq_cache["ids"] and now - _groq_cache["t"] < 6 * 3600) or (now - _groq_cache.get("fail_t", 0) < 60)):
        return _groq_cache["ids"]
    ids = []
    try:
        r = requests.get(GROQ_BASE + "/models", headers={"Authorization": "Bearer " + _env_key("GROQ_API_KEY")}, timeout=20)
        if r.status_code == 200:
            try:
                data = r.json()
            except ValueError:
                _groq_cache["err"] = f"HTTP 200 بس الرد مو JSON: {r.text[:80]!r}"
                return _groq_cache["ids"]
            ids = [i["id"] for i in (data.get("data") or []) if isinstance(i, dict) and i.get("id")]
            _groq_cache["err"] = "" if ids else "القائمة رجعت فاضية"
        else:
            _groq_cache["err"] = f"HTTP {r.status_code}: {r.text[:200]}"
            log.error("Groq catalog %s", _groq_cache["err"])
    except Exception as e:
        _groq_cache["err"] = f"{type(e).__name__}: {e}"
        log.error("Groq catalog error: %s", e)
    if ids:
        _groq_cache.update(t=now, ids=ids, fail_t=0.0)
    else:
        _groq_cache["fail_t"] = now
    return ids or _groq_cache["ids"]


def groq_code_models():
    """أفضل موديلات الكود المتاحة فعلاً عند Groq، بالترتيب (الأسماء الميتة بتنتخطى)."""
    ids = groq_catalog()
    order = []
    env = os.environ.get("GROQ_CODE_MODEL", "").strip()
    if env:
        order.append(env)
    for p in GROQ_CODE_PREF:
        if (not ids or p in ids) and p not in order:
            order.append(p)
    for i in ids:
        low = i.lower()
        if i not in order and any(k in low for k in ("gpt-oss", "qwen", "llama", "kimi")) and not any(x in low for x in _GROQ_SKIP):
            order.append(i)
    return order[:4]


_CODE_STRONG = re.compile(
    r"(```|\bdef \w+\(|\bimport \w+|#include|console\.log|\bSELECT\b.+\bFROM\b|<\s*(div|html|script)\b|"
    r"\b(python|javascript|typescript|java|c\+\+|c#|php|html|css|sql|bash|react|flask|django|node\.?js|kotlin|swift|rust|golang|regex)\b|"
    r"بايثون|جافاسكربت|جافا سكربت|\bجافا\b)",
    re.I | re.S,
)
_CODE_WEAK = ("كود", "كودات", "برمج", "برمجة", "دالة", "دوال", "خوارزمية", "debug", "bug", "كلاس", "function", "algorithm")
def is_code_request(text):
    """فحص ما إذا كان الطلب برمجياً."""
    t = (text or "").lower()
    if _CODE_STRONG.search(text or ""):
        return True
    return any(w in t for w in _CODE_WEAK)


def ask_openai_compat(prov, contents, deep=False, json_mode=False):
    last = None
    for b in PROVIDERS[prov]["backends"]:
        if not _backend_ready(b):
            continue
        try:
            return _call_backend(b, contents, deep, json_mode)
        except ProviderError as e:
            last = e
    raise last or ProviderError(None, "no backend ready")

def ask_model(chat_id, contents, deep=False, json_mode=False, code=False):
    """طلبات الكود بتروح تلقائياً لـ Groq، وإذا فشل بيجاوب Gemini. (إلا إذا اخترت موديل بإيدك أو طفّيت /code)."""
    pre_note = None
    if (code and not json_mode and _groq_ready() and chat_id not in code_route_off
            and chat_id not in chat_provider and _text_only(contents)):
        try:
            out = {}
            ans = _call_backend(GROQ_BACKEND, contents, deep, False, models=groq_code_models(), out=out)
            if ans:
                return ans, f"(الكود من Groq: {out.get('model')})"
        except Exception as e:
            c = getattr(e, "code", None)
            log.error("Groq code route failed (%s): %s", c, e)
            pre_note = "(Groq ما اشتغل" + (f"، رمز {c}" if c else "") + "، جاوب Gemini)"
    ans, note = _ask_model_core(chat_id, contents, deep=deep, json_mode=json_mode)
    return ans, (note or pre_note)


def _ask_model_core(chat_id, contents, deep=False, json_mode=False):
    """بيرجّع (الجواب، ملاحظة) مع دعم جميع النماذج المجانية (Gemini / Groq / OpenRouter / Codestral) والتبديل الذكي عند ضغط السيرفر."""
    prov = chat_provider.get(chat_id, DEFAULT_PROVIDER)
    text_only = _text_only(contents)

    if not text_only and not (prov == "gemini" or prov.startswith("gemini:")):
        ans = ask_gemini(contents, deep=deep, json_mode=json_mode)
        return ans, f"(استخدمت Gemini لأن {_pname(prov)} ما بيقدر يقرأ صور/صوت)"

    if prov == "mix":
        return ask_mix(contents, deep=deep)

    if prov == "gemini" or prov.startswith("gemini:"):
        pref_m = prov[7:] if prov.startswith("gemini:") else None
        ans = ask_gemini(contents, deep=deep, json_mode=json_mode, preferred_model=pref_m)
        return ans, (pref_m if pref_m else None)

    if prov == "codestral":
        c_key = _env_key("CODESTRAL_API_KEY")
        if c_key:
            try:
                c_backend = {
                    "name": "Codestral",
                    "base": "https://codestral.mistral.ai/v1",
                    "key_env": "CODESTRAL_API_KEY",
                    "timeout_fast": 60,
                    "timeout_deep": 120,
                    "system": CODE_SYSTEM_PROMPT,
                }
                ans = _call_backend(c_backend, contents, deep, json_mode, models=[os.environ.get("CODESTRAL_MODEL", "codestral-latest")])
                if ans:
                    return ans, "Codestral"
            except Exception as e:
                log.warning("Codestral direct fallback: %s", e)
        if _or_key():
            b_or = {**OR_BACKEND, "prov": "mistral", "match": ("codestral", "mistral")}
            ans = _call_backend(b_or, contents, deep, json_mode)
            if ans:
                return ans, "Codestral (OR)"

    if prov.startswith("groq:"):
        target_m = prov[5:]
        if not _groq_ready():
            if client:
                ans = ask_gemini(contents, deep=deep, json_mode=json_mode)
                return ans, "(احتياط Gemini — مفتاح Groq غير مضاف)"
            raise ProviderError(401, "GROQ_API_KEY مو مضاف على Render")
        avail_g = groq_code_models()
        chain_g = [target_m] + [m for m in avail_g if m != target_m]
        out_g = {}
        try:
            ans = _call_backend(GROQ_CHAT_BACKEND, contents, deep, json_mode, models=chain_g, out=out_g)
            if ans:
                used_m = out_g.get("model") or target_m
                note_g = None if used_m == target_m else f"(تبديل ذكي إلى {used_m})"
                return ans, note_g
        except Exception as e:
            if client:
                log.warning("Groq model %s failed (%s), falling back to Gemini", target_m, e)
                ans = ask_gemini(contents, deep=deep, json_mode=json_mode)
                return ans, f"(استخدمت Gemini لأن {_pname(prov)} مضغوط حالياً)"
            raise ProviderError(getattr(e, "code", None), f"{_pname(prov)} ← {e}")
        raise ProviderError(502, f"{_pname(prov)} ← رد فاضي")

    if prov.startswith("or:"):
        target_or = prov[3:]
        if not _or_key():
            if client:
                ans = ask_gemini(contents, deep=deep, json_mode=json_mode)
                return ans, "(احتياط Gemini — مفتاح OpenRouter غير مضاف)"
            raise ProviderError(401, "OPENROUTER_API_KEY مو مضاف على Render")
        b = {**OR_BACKEND, "prov": "custom", "match": ()}
        free_fallbacks = [m for m in free_chat_models(limit=12) if m != target_or]
        chain_or = [target_or] + free_fallbacks[:4]
        if "openrouter/free" not in chain_or:
            chain_or.append("openrouter/free")
        out_or = {}
        try:
            ans = _call_backend(b, contents, deep, json_mode, models=chain_or, out=out_or)
            if ans:
                used_m = out_or.get("model") or target_or
                note_or = None if used_m == target_or else f"(تبديل ذكي إلى {used_m.replace(':free', '')})"
                return ans, note_or
        except Exception as e:
            if client:
                log.warning("OpenRouter model %s failed (%s), falling back to Gemini", target_or, e)
                ans = ask_gemini(contents, deep=deep, json_mode=json_mode)
                return ans, f"(استخدمت Gemini لأن {_pname(prov)} مضغوط حالياً)"
            raise ProviderError(getattr(e, "code", None), f"{_pname(prov)} ← {e}")
        raise ProviderError(502, f"{_pname(prov)} ← رد فاضي")

    if prov in PROVIDERS and provider_ready(prov):
        try:
            ans = ask_openai_compat(prov, contents, deep=deep, json_mode=json_mode)
            if ans:
                return ans, None
        except Exception as e:
            if client:
                ans = ask_gemini(contents, deep=deep, json_mode=json_mode)
                return ans, f"(استخدمت Gemini لأن {_pname(prov)} مضغوط حالياً)"
            code = getattr(e, "code", None)
            raise ProviderError(code, f"{_pname(prov)} ← {e}")

    raise ValueError(f"الموديل {_pname(prov)} مو متاح.")


# ============ Ryn mix: محرك Ryn mix المطور (مستوحى من gstack) ============
MIX_SYSTEM = (
    "أنت Ryn (من تطوير haydar_xe). وصلك سؤال المستخدم مع إجابات عدة موديلات ذكاء اصطناعي. "
    "ادمجهم بجواب واحد نهائي، صحيح ومرتب ومختصر: خذ الأدق من كل إجابة، "
    "وصحّح أي تناقض أو خطأ، وما تذكر أسماء الموديلات ولا إنك قارنت إجابات. "
    "حافظ بالكامل على أي بلوكات <github_patch> أو <github_create> أو <github_delete> موجودة لتنفيذ تعديلات GitHub. "
    "جاوب بلغة المستخدم، وإذا كتب عربي جاوب بلهجة شامية بسيطة. "
    "إذا في معلومة مو متأكد منها قول هيك بصراحة وما تخترع."
)


def _redact_bot_secrets(text):
    if webapp is not None and hasattr(webapp, "redact_secrets"):
        return webapp.redact_secrets(text)
    return text or ""


def _mix_members(deep, code=False):
    members = [("Gemini", lambda c: ask_gemini(c, deep=False))]
    if _groq_ready():
        ids = groq_catalog()
        gpt = "openai/gpt-oss-120b"
        if not ids or gpt in ids:
            members.append(("GPT-OSS", lambda c: _call_backend(GROQ_CHAT_BACKEND, c, False, False, models=[gpt])))
        qw = sorted([i for i in ids if "qwen" in i.lower() and not any(x in i.lower() for x in _GROQ_SKIP)], reverse=True)
        if qw:
            members.append(("Qwen", lambda c, m=qw[0]: _call_backend(GROQ_CHAT_BACKEND, c, False, False, models=[m])))
    if _or_key():
        members.append(("DeepSeek", lambda c: ask_openai_compat("deepseek", c, deep=False)))
    return members


def ask_mix(contents, deep=False):
    import concurrent.futures as cf
    question = ""
    for c in reversed(contents):
        if c.role == "user":
            question = "\n".join(p.text for p in c.parts if getattr(p, "text", None))
            break
    code_req = is_code_request(question)
    if webapp is not None and hasattr(webapp, "mix_answer"):
        try:
            fix_req = bool(webapp._FIX_RE.search(question)) if hasattr(webapp, "_FIX_RE") else False
            is_eng = webapp.is_mix_engineering_request(question) if hasattr(webapp, "is_mix_engineering_request") else (code_req or fix_req)
            ans, note = webapp.mix_answer(
                sys.modules[__name__], contents, _mix_members(deep, code=is_eng),
                code=is_eng, fix=fix_req
            )
            ans = re.sub(r"\[\[MEM:\s*.+?\s*\]\]", "", ans or "").strip()
            return _redact_bot_secrets(ans), f"({note})"
        except Exception as e:
            log.warning("Ryn mix (webapp engine) fallback: %s", _redact_bot_secrets(str(e)[:160]))
    members = _mix_members(deep, code=code_req)
    answers = {}
    ex = cf.ThreadPoolExecutor(max_workers=max(1, len(members)))
    futs = {ex.submit(fn, contents): name for name, fn in members}
    try:
        for f in cf.as_completed(futs, timeout=60 if code_req else 45):
            name = futs[f]
            try:
                t = _redact_bot_secrets((f.result() or "").strip())
                if t:
                    answers[name] = t[:12000 if code_req else 6000]
            except Exception as e:
                log.warning("Ryn mix: %s فشل: %s", name, _redact_bot_secrets(str(e)[:160]))
    except cf.TimeoutError:
        log.warning("Ryn mix: خلصت المهلة، بكمّل بالأجوبة يلي وصلت")
    ex.shutdown(wait=False)
    if not answers:
        raise ProviderError(502, "Ryn mix ← ولا موديل رد")
    if len(answers) == 1:
        name, only = next(iter(answers.items()))
        return only, f"(Ryn mix: رد {name} بس، الباقي ما اشتغل)"
    block = "\n\n".join(f"--- إجابة {i} ---\n{t}" for i, t in enumerate(answers.values(), 1))
    prompt = f"سؤال المستخدم:\n{_redact_bot_secrets(question[:6000])}\n\n{block}\n\nاكتب الجواب النهائي المدموج فقط."
    final = None
    try:
        final = ask_gemini([types.Content(role="user", parts=[types.Part(text=prompt)])],
                           deep=False, system=MIX_SYSTEM)
    except Exception as e:
        log.warning("Ryn mix: الدمج فشل: %s", _redact_bot_secrets(str(e)[:160]))
    if not final:
        final = max(answers.values(), key=len)
    return _redact_bot_secrets(final), "(Ryn mix: " + " + ".join(answers.keys()) + ")"


def friendly_error(e):
    code = getattr(e, "code", None)
    safe_err = _redact_bot_secrets(str(e)[:350])
    tag = f"\n(الخطأ: {safe_err})" if isinstance(e, ProviderError) else (f"\n(رمز: {code})" if code else f"\n({type(e).__name__})")
    if code == 429:
        msg = "⏳ السيرفرات مضغوطة حالياً أو خلص الحد المجاني للطلب، جرّب بعد شوي."
    elif code in (500, 502, 503, 504):
        msg = "⏳ السيرفرات تبع الذكاء الاصطناعي مو مستقرة، جرّب تاني."
    elif code in (401, 403):
        msg = "🔑 في مشكلة بالمفتاح السري بالـ Environment Variables."
    elif code == 404:
        msg = "⚠️ هالموديل مو متاح هلأ (ممكن شالوا المجاني منو). جرّب /models واختار غيرو."
    else:
        msg = "⚠️ صار خطأ أثناء المعالجة، جرّب مرة تانية."
    return msg + tag

def process(message, user_parts, history_label, deep=False):
    chat_id = message.chat.id
    if is_spam(chat_id):
        bot.reply_to(message, "استنى شوي وأرسل تاني 🙂")
        return
    status = None
    try:
        if deep:
            try:
                status = bot.send_message(chat_id, "🧠 سؤال مركّب، عم فكر فيه بعمق...")
            except Exception:
                _ = None
        with typing(chat_id):
            tg_uid = f"tg_{chat_id}"
            if AIStack is not None:
                direct_gh = AIStack.get_github_manager().handle_direct_chat_command(tg_uid, history_label)
                if direct_gh:
                    send_long(message, direct_gh)
                    save_turn(chat_id, history_label, direct_gh)
                    return
                try:
                    gh_ctx = AIStack.get_github_manager().build_chat_github_context(tg_uid, history_label)
                    if gh_ctx:
                        user_parts = [types.Part(text=gh_ctx)] + list(user_parts)
                except Exception:
                    _ = None
            contents = build_contents(chat_id)
            contents.append(types.Content(role="user", parts=user_parts))
            answer, note = ask_model(chat_id, contents, deep=deep, code=is_code_request(history_label))
            if AIStack is not None and answer:
                try:
                    answer, _ = AIStack.get_github_manager().apply_chat_github_actions(tg_uid, history_label, answer)
                except Exception:
                    _ = None
        if answer:
            send_long(message, answer + (f"\n\n{note}" if note else ""))
            save_turn(chat_id, history_label, answer)
        else:
            bot.reply_to(message, "ما قدرت أجاوب على هاد، جرّب صياغة تانية.")
    except Exception as e:
        log.exception("Process error")
        bot.reply_to(message, friendly_error(e))
    finally:
        if status:
            try:
                bot.delete_message(chat_id, status.message_id)
            except Exception:
                _ = None

# ============ قراءة الملفات ============
DOC_TTL = 30 * 60
MAX_FILE_BYTES = 15 * 1024 * 1024   # تيليجرام (حد تنزيل البوت 20MB)
INLINE_MAX_BYTES = 15 * 1024 * 1024  # أكبر ملف بينرسل inline لـ Gemini

MIME_BY_EXT = {
    ".pdf": "application/pdf",
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
}
TEXT_EXT = {".txt", ".md", ".csv", ".json", ".py", ".js", ".ts", ".html", ".css", ".xml",
            ".log", ".ini", ".yaml", ".yml", ".lua", ".java", ".c", ".cpp", ".cs", ".sql", ".tsv"}

doc_ctx = {}

def _docx_text(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        xml = z.read("word/document.xml").decode("utf-8", "ignore")
    xml = xml.replace("</w:p>", "\n").replace("<w:tab/>", "\t")
    return html.unescape(re.sub(r"<[^>]+>", "", xml))

def build_doc_parts(name, data):
    ext = os.path.splitext(name.lower())[1]
    if ext == ".pdf" and len(data) > INLINE_MAX_BYTES:
        # PDF كبير: ما بينفع يرسل inline لـ Gemini، فبنستخرج النصّ محلياً
        parts = pdf_alt_parts(name, data, max_pages=2000, cap=1_500_000)
        if not parts:
            raise ValueError("pdf_big")
        return parts
    if ext in MIME_BY_EXT:
        return [types.Part.from_bytes(data=data, mime_type=MIME_BY_EXT[ext])]
    if ext == ".docx":
        try:
            text = _docx_text(data)
        except Exception:
            raise ValueError("bad_docx")
    elif ext in TEXT_EXT:
        text = None
        for enc in ("utf-8-sig", "cp1256"):
            try:
                text = data.decode(enc)
                break
            except Exception:
                continue
    else:
        raise ValueError("unsupported")
    text = (text or "").strip()
    if not text:
        raise ValueError("empty")
    if len(text) > 150_000:
        text = text[:150_000] + "\n...[انقطع الملف لأنه طويل]"
    return [types.Part(text=f"[محتوى الملف: {name}]\n{text}")]

def pdf_alt_parts(name, data, max_pages=60, cap=150_000):
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(data))
        text = "\n".join((pg.extract_text() or "") for pg in list(reader.pages)[:max_pages]).strip()
    except Exception:
        return None
    if len(text) < 200:
        return None
    if len(text) > cap:
        text = text[:cap] + "\n...[انقطع الملف لأنه طويل]"
    return [types.Part(text=f"[محتوى الملف: {name}]\n{text}")]

def set_doc(chat_id, name, parts, alt=None):
    doc_ctx[chat_id] = {"name": name, "parts": parts, "alt": alt, "exp": time.time() + DOC_TTL}

def get_doc(chat_id):
    ctx = doc_ctx.get(chat_id)
    if ctx and ctx["exp"] < time.time():
        doc_ctx.pop(chat_id, None)
        return None
    return ctx

# ============ الأوامر ============
@bot.message_handler(commands=["start"])
def cmd_start(message):
    bot.reply_to(
        message,
        "أهلاً فيك! 👋\nابعتلي أي سؤال أو صورة أو رسالة صوتية وأنا بجاوبك.\n"
        "/reset لمسح الذاكرة\n/help للمساعدة",
    )

@bot.message_handler(commands=["help"])
def cmd_help(message):
    lines = [
        "• اكتب سؤالك عادي",
        "• ابعت صورة مع تعليق (اختياري)",
        "• ابعت ملف (PDF / Word / نص) مع سؤال، وبضل مرفق 30 دقيقة",
        "• ابعت رسالة صوتية",
        "• /deep سؤالك  ←  تفكير عميق + مراجعة الجواب",
        "• /model  ←  تبديل الموديل (Gemini / ChatGPT / Llama / Claude...)",
        "• طلبات الكود البرمجي بتروح تلقائياً لـ Groq  (/code on|off)",
    ]
    lines += ["• /clearfile لحذف الملف المرفق", "• /reset لبدء محادثة جديدة"]
    bot.reply_to(message, "\n".join(lines))

@bot.message_handler(commands=["deep"])
def cmd_deep(message):
    text = (message.text or "").partition(" ")[2].strip()
    if not text:
        bot.reply_to(message, "اكتب سؤالك بعد الأمر، مثال:\n/deep كيف أعمل نظام دم لا نهائي؟")
        return
    process(message, [types.Part(text=text)], text, deep=True)

@bot.message_handler(commands=["clearfile"])
def cmd_clearfile(message):
    doc_ctx.pop(message.chat.id, None)
    bot.reply_to(message, "🗑️ تم حذف الملف من المحادثة.")

@bot.message_handler(commands=["model"])
def cmd_model(message):
    arg = (message.text or "").partition(" ")[2].strip().lower()
    aliases = {
        "gemini": "gemini", "جيميني": "gemini",
        "mix": "mix", "ryn mix": "mix", "مكس": "mix", "راين مكس": "mix",
        "deepseek": "deepseek", "ديب سيك": "deepseek", "ديبسيك": "deepseek",
        "qwen": "qwen", "كوين": "qwen",
        "chatgpt": "chatgpt", "gpt": "chatgpt", "شات جي بي تي": "chatgpt",
        "claude": "claude", "كلود": "claude",
        "llama": "llama", "لاما": "llama"
    }
    chat_id = message.chat.id

    if arg and arg not in aliases:
        # اختيار موديل مجاني من OpenRouter: برقم (من /models) أو بجزء من اسمه أو free
        if not _or_key():
            bot.reply_to(message, "OPENROUTER_API_KEY مو مضاف على Render.")
            return
        free = free_chat_models()
        pick = None
        if arg.isdigit():
            lst = last_models.get(chat_id) or free
            idx = int(arg) - 1
            pick = lst[idx] if 0 <= idx < len(lst) else None
            if not pick:
                bot.reply_to(message, "الرقم مو بالقائمة. ابعت /models وشوف الأرقام.")
                return
        elif arg in ("free", "auto", "مجاني"):
            pick = "openrouter/free" if "openrouter/free" in free else None
            if not pick:
                bot.reply_to(message, "راوتر المجاني (openrouter/free) مو متاح حالياً. جرّب /models.")
                return
        else:
            q = arg.replace(" ", "-")
            hits = [i for i in free if q in i.lower()]
            if not hits:
                bot.reply_to(message, f"ما لقيت موديل مجاني فيه «{arg}». جرّب /models.")
                return
            if len(hits) > 1:
                last_models[chat_id] = hits[:10]
                bot.reply_to(message, "لقيت أكتر من واحد، اختار رقم:\n" +
                             "\n".join(f"{n}) {h.replace(':free', '')}" for n, h in enumerate(hits[:10], 1)) +
                             "\n\nمثال: /model 1")
                return
            pick = hits[0]
        chat_provider[chat_id] = "or:" + pick
        bot.reply_to(message, f"✅ صرت أجاوب بـ {pick.replace(':free', '')}، وكملنا بنفس المحادثة.")
        return

    if arg in aliases:
        name = aliases[arg]
        if not provider_ready(name):
            bot.reply_to(message, "مفتاح OPENROUTER_API_KEY مو مضاف على Render.")
            return
        chat_provider[chat_id] = name
        bot.reply_to(message, f"✅ صرت أجاوب بـ {PROVIDER_NAMES[name]}.")
        return
        
    cur = chat_provider.get(chat_id, DEFAULT_PROVIDER)
    kb = telebot.types.InlineKeyboardMarkup()
    lines = []
    for name, label in PROVIDER_NAMES.items():
        mark = "✅ " if name == cur else ("" if provider_ready(name) else "⚠️ ")
        kb.add(telebot.types.InlineKeyboardButton(mark + label, callback_data=f"mdl:{name}"))
        lines.append(f"• {label}")
    
    bot.send_message(
        chat_id,
        f"الموديل الحالي: {_pname(cur)}\n" + "\n".join(lines) +
        "\n\n• تم إيقاف التبديل التلقائي.\n• كل الموديلات (غير Gemini) بتشتغل عن طريق OpenRouter، والمجاني منها بس.\n• /models بيعرض المتاح، و/model 3 بيختار رقم 3.",
        reply_markup=kb)

@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("mdl:"))
def cb_model(call):
    name = call.data.split(":", 1)[1]
    try:
        if name not in PROVIDER_NAMES or not provider_ready(name):
            bot.answer_callback_query(call.id, "المفتاح مو مضاف على Render")
            return
        chat_provider[call.message.chat.id] = name
        bot.answer_callback_query(call.id, f"تم: {PROVIDER_NAMES[name]}")
        bot.send_message(call.message.chat.id, f"✅ صرت أجاوب بـ {PROVIDER_NAMES[name]}.")
    except Exception:
        log.exception("Model switch error")

@bot.message_handler(commands=["models", "ghmodels"])
def cmd_models(message):
    if not _or_key():
        bot.reply_to(message, "OPENROUTER_API_KEY مو مضاف على Render.")
        return
    items = openrouter_catalog(force=True)
    if not items:
        bot.reply_to(message, "ما قدرت أجيب قائمة موديلات OpenRouter.\nالسبب: " + (_or_cache.get("err") or "مجهول"))
        return
    free = free_chat_models()
    last_models[message.chat.id] = free
    lines = [f"OpenRouter: {len(items)} موديل، منهم {len(free_chat_models(limit=10**6))} مجاني للمحادثة."]
    fam = []
    for name in ("chatgpt", "llama", "claude", "deepseek", "qwen"):
        b = PROVIDERS[name]["backends"][0]
        ids = or_models_for(name, b["match"], True)
        fam.append(f"{PROVIDER_NAMES[name]}: " + (ids[0].replace(":free", "") if ids else "ما في مجاني"))
    lines.append("• " + " | ".join(fam))
    if free:
        lines.append("\nالمجاني الصالح للمحادثة (اختار برقم: /model 3):")
        lines += [f"{n}) {i.replace(':free', '')}" for n, i in enumerate(free[:30], 1)]
    else:
        lines.append("\nما في موديلات مجانية متاحة حالياً. ممكن OpenRouter شالها، أو لازم رصيد (OPENROUTER_ALLOW_PAID=1).")
    bot.reply_to(message, "\n".join(lines)[:3900])


@bot.message_handler(commands=["ortest", "ghtest"])
def cmd_ortest(message):
    """تشخيص: /ortest [model]  ← بيجرب طلب واحد وبيعرض رد OpenRouter الخام."""
    key = _or_key()
    if not key:
        bot.reply_to(message, "OPENROUTER_API_KEY مو مضاف على Render.")
        return
    model = (message.text or "").partition(" ")[2].strip()
    if not model:
        ids = free_chat_models()
        model = ids[0] if ids else "openrouter/free"
    url = OR_BASE + "/chat/completions"
    lines = [f"الموديل: {model}", f"الرابط: {url}", f"المفتاح: يبدأ بـ {key[:8]}… طوله {len(key)}"]
    try:
        r = requests.post(
            url,
            headers={"Authorization": "Bearer " + key, "Content-Type": "application/json",
                     "X-Title": "Ryn"},
            json={"model": model, "messages": [{"role": "user", "content": "قول مرحبا بكلمة وحدة"}], "stream": False},
            timeout=90,
        )
        lines.append(f"\nHTTP {r.status_code} | {_diag(r)}\nالرد: {r.text[:400]!r}")
    except Exception as e:
        lines.append(f"\nخطأ شبكة: {type(e).__name__}: {str(e)[:200]}")
    bot.reply_to(message, "\n".join(lines)[:3900])


@bot.message_handler(commands=["code"])
def cmd_code(message):
    arg = (message.text or "").partition(" ")[2].strip().lower()
    cid = message.chat.id
    if arg in ("off", "اطفاء", "إطفاء", "طفي"):
        code_route_off.add(cid)
        bot.reply_to(message, "🔕 طفّيت توجيه الكود التلقائي. الكود هلأ بيجاوب فيه الموديل الحالي.")
        return
    if arg in ("on", "تشغيل", "شغل"):
        code_route_off.discard(cid)
    state = "شغّال ✅" if (cid not in code_route_off) else "مطفّي 🔕"
    key = "المفتاح موجود" if _groq_ready() else "GROQ_API_KEY مو مضاف على Render"
    bot.reply_to(message, f"توجيه الكود التلقائي لـ Groq: {state}\n({key})\n"
                          "الأوامر: /code on ، /code off ، /groqmodels")


@bot.message_handler(commands=["groqmodels"])
def cmd_groqmodels(message):
    if not _groq_ready():
        bot.reply_to(message, "GROQ_API_KEY مو مضاف على Render.")
        return
    ids = groq_catalog(force=True)
    if not ids:
        bot.reply_to(message, "ما قدرت أجيب قائمة موديلات Groq.\nالسبب: " + (_groq_cache.get("err") or "مجهول"))
        return
    chosen = groq_code_models()
    bot.reply_to(message, "موديلات الكود المستعملة (بالترتيب):\n" + "\n".join(f"{n}) {m}" for n, m in enumerate(chosen, 1)) +
                 f"\n\nكل موديلات Groq ({len(ids)}):\n" + "\n".join(ids[:40]))


@bot.message_handler(commands=["mixtest"])
def cmd_mixtest(message):
    """تشغيل اختبارات الجودة الذاتية لـ Ryn mix وعرض ترتيب الموديلات حسب الأداء (المرحلة 10)."""
    if webapp is None or not hasattr(webapp, "run_ryn_mix_quality_suite"):
        bot.reply_to(message, "وحدة اختبارات Ryn mix غير متاحة حالياً.")
        return
    res = webapp.run_ryn_mix_quality_suite()
    lines = [f"🧪 اختبارات جودة Ryn mix: {res['passed_count']}/{res['total']} نجحت"]
    for t in res["tasks"]:
        mark = "✅" if t["passed"] else "❌"
        lines.append(f"\n{mark} {t['title']}:")
        for d in t["details"]:
            lines.append(f"  • {d}")
    rk = res.get("model_rankings") or {}
    if rk.get("writers"):
        lines.append("\n🏆 ترتيب الكتّاب حسب الأداء: " + " ← ".join(rk["writers"][:5]))
    if rk.get("reviewers"):
        lines.append("🔎 ترتيب المراجعين حسب الأداء: " + " ← ".join(rk["reviewers"][:5]))
    bot.reply_to(message, "\n".join(lines))


@bot.message_handler(commands=["reset"])
def cmd_reset(message):
    doc_ctx.pop(message.chat.id, None)
    with lock:
        histories.pop(message.chat.id, None)
    bot.reply_to(message, "🧹 تم مسح الذاكرة.")

# ============ الرسائل ============
@bot.message_handler(content_types=["text"])
def handle_text(message):
    text = (message.text or "").strip()
    if not text:
        return
    ctx = get_doc(message.chat.id)
    if ctx:
        base = ctx["alt"] if ctx.get("alt") else ctx["parts"]
        parts = base + [types.Part(text=text)]
        label = f"[بخصوص الملف {ctx['name']}] {text}"
    else:
        parts, label = [types.Part(text=text)], text
    process(message, parts, label, deep=is_deep_question(text))

@bot.message_handler(content_types=["photo"])
def handle_photo(message):
    try:
        info = bot.get_file(message.photo[-1].file_id)
        data = bot.download_file(info.file_path)
    except Exception:
        log.exception("Photo download error")
        bot.reply_to(message, "ما قدرت أنزّل الصورة، جرّب تاني.")
        return
    caption = (message.caption or "").strip()
    if caption and webapp is not None and hasattr(webapp, "_IMG_EDIT_INTENT_RE") and webapp._IMG_EDIT_INTENT_RE.search(caption):
        try:
            with typing(message.chat.id):
                if hasattr(webapp, "G") and webapp.G is not None and hasattr(webapp.G, "validate_image_upload"):
                    up_chk = webapp.G.validate_image_upload(data, "telegram_photo.jpg")
                    if not up_chk.get("ok"):
                        bot.reply_to(message, "⚠️ ملف الصورة المرفوع غير صالح أمنياً.")
                        return
                ref_p = [types.Part.from_bytes(data=data, mime_type="image/jpeg")]
                vb = webapp.get_visual_brain() if hasattr(webapp, "get_visual_brain") and webapp.get_visual_brain is not None else None
                tg_uid = f"tg_{message.chat.id}"
                if vb is not None:
                    p2p_inst = webapp.InstructPix2PixProvider(sys.modules[__name__]) if getattr(webapp, "InstructPix2PixProvider", None) is not None else None
                    p2p_ready = bool(p2p_inst and p2p_inst.is_ready())
                    plan = vb.build_plan(
                        user_text=caption,
                        user_id=tg_uid,
                        attached_images_bytes=[data],
                        available_providers={"instruct_pix2pix": p2p_ready, "gemini": bool(client), "flux": False},
                        aspect_hint_str=webapp.aspect_hint(caption),
                        ref_parts=ref_p,
                    )
                    tg_runners = {}
                    if p2p_ready:
                        tg_runners["instruct_pix2pix"] = lambda p_en, r_p=None: p2p_inst.generate(p_en, ref_parts=r_p or ref_p)
                    if client:
                        tg_runners["gemini"] = lambda p_en, r_p=None: webapp.gemini_image(sys.modules[__name__], p_en, ref_parts=r_p or ref_p)
                    def _tg_vision_critic(gen_b, audit_q):
                        return ask_gemini([types.Content(role="user", parts=[types.Part.from_bytes(data=gen_b, mime_type="image/png"), types.Part(text=audit_q)])], deep=False)
                    exec_out = vb.execute_plan(
                        plan,
                        user_id=tg_uid,
                        provider_runners=tg_runners,
                        ref_parts=ref_p,
                        vision_audit_fn=_tg_vision_critic if client else None,
                    )
                    out_bytes = exec_out.get("image_bytes")
                else:
                    en = webapp.english_prompt(sys.modules[__name__], caption, is_edit=True, has_ref_image=True)
                    ah = webapp.aspect_hint(caption)
                    full_p = (en + ((" " + ah) if ah else "")).strip()
                    out_bytes, _mime, _mdl = webapp.gemini_image(sys.modules[__name__], full_p, ref_parts=ref_p)
                bio = io.BytesIO(out_bytes)
                bio.name = "edited.png"
                bot.send_photo(message.chat.id, bio, caption="🎨 تم تعديل الصورة عبر العقل البصري مع الحفاظ على الهوية والتفاصيل", reply_to_message_id=message.message_id)
                return
        except Exception as e:
            log.warning("Telegram photo edit fallback to chat: %s", e)
    caption = caption or "اشرح هالصورة."
    parts = [
        types.Part.from_bytes(data=data, mime_type="image/jpeg"),
        types.Part(text=caption),
    ]
    process(message, parts, f"[صورة: {caption}]", deep=bool(message.caption) and is_deep_question(caption))

@bot.message_handler(content_types=["voice"])
def handle_voice(message):
    try:
        info = bot.get_file(message.voice.file_id)
        data = bot.download_file(info.file_path)
    except Exception:
        log.exception("Voice download error")
        bot.reply_to(message, "ما قدرت أنزّل الرسالة الصوتية، جرّب تاني.")
        return
    parts = [
        types.Part.from_bytes(data=data, mime_type="audio/ogg"),
        types.Part(text="افهم هالرسالة الصوتية وجاوب عليها."),
    ]
    process(message, parts, "[رسالة صوتية]")

@bot.message_handler(content_types=["document"])
def handle_document(message):
    doc = message.document
    name = doc.file_name or "file"
    if doc.file_size and doc.file_size > MAX_FILE_BYTES:
        bot.reply_to(message, "الملف كبير، الحد الأقصى 15 ميجا. 📦")
        return
    try:
        info = bot.get_file(doc.file_id)
        data = bot.download_file(info.file_path)
    except Exception:
        log.exception("Document download error")
        bot.reply_to(message, "ما قدرت أنزّل الملف، جرّب تاني.")
        return
    try:
        parts = build_doc_parts(name, data)
    except ValueError as e:
        reason = str(e)
        if reason == "unsupported":
            msg = "نوع الملف مو مدعوم حالياً. المدعوم: PDF، Word (docx)، صور، وملفات نصية."
        elif reason == "empty":
            msg = "الملف فاضي أو ما قدرت أقرأ نصه."
        else:
            msg = "ما قدرت أفتح الملف، يمكن تالف."
        bot.reply_to(message, msg)
        return
    chat_id = message.chat.id
    alt = pdf_alt_parts(name, data) if name.lower().endswith(".pdf") else None
    set_doc(chat_id, name, parts, alt)
    question = (message.caption or "").strip() or "لخّصلي هالملف واذكر أهم النقاط."
    base = alt if alt else parts
    process(message, base + [types.Part(text=question)],
            f"[ملف: {name}] {question}", deep=is_deep_question(question))
    try:
        bot.send_message(chat_id, "📎 الملف مرفق بالمحادثة 30 دقيقة، اسأل عنه براحتك. /clearfile لحذفه.")
    except Exception:
        _ = None

@bot.message_handler(content_types=["sticker", "video", "audio"])
def handle_unsupported(message):
    bot.reply_to(message, "حالياً بدعم النص والصور والملفات والرسائل الصوتية بس 🙂")

# ============ التشغيل ============
def run_polling():
    while True:
        try:
            log.info("Polling started | models=%s", MODELS)
            bot.infinity_polling(skip_pending=True, timeout=20, long_polling_timeout=20)
        except Exception as e:
            log.error("Polling crashed: %s", e)
            time.sleep(5)

if __name__ == "__main__":
    if webapp is not None:
        try:
            webapp.register(app, sys.modules[__name__])
        except Exception:
            log.exception("تعذر تفعيل الموقع")
    if ENABLE_TELEGRAM:
        threading.Thread(target=run_polling, daemon=True).start()
    else:
        log.info("تيليجرام مطفّي، الموقع بس شغّال")
    app.run(host="0.0.0.0", port=PORT)
